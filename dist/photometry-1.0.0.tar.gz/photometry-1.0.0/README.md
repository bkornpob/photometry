# Photometry

Photometry is a class containing methods for computing photometry with local 2D-polynomial background estimation.